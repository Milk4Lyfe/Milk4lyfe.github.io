﻿namespace Clickity
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            button1 = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            label2 = new Label();
            button2 = new Button();
            listBox1 = new ListBox();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            second1 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            label1 = new Label();
            button10 = new Button();
            numericUpDown1 = new NumericUpDown();
            linkLabel1 = new LinkLabel();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(195, 118);
            button1.Margin = new Padding(4, 2, 4, 2);
            button1.Name = "button1";
            button1.Size = new Size(337, 110);
            button1.TabIndex = 0;
            button1.Text = "Click to start";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick_1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Yet R", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(397, 71);
            label2.Name = "label2";
            label2.Size = new Size(106, 26);
            label2.TabIndex = 2;
            label2.Text = "0 clicks";
            label2.Click += label2_Click;
            // 
            // button2
            // 
            button2.Enabled = false;
            button2.Location = new Point(302, 250);
            button2.Name = "button2";
            button2.Size = new Size(134, 52);
            button2.TabIndex = 3;
            button2.Text = "Restart";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 16;
            listBox1.Location = new Point(539, 55);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(321, 212);
            listBox1.TabIndex = 4;
            // 
            // button3
            // 
            button3.Location = new Point(670, 273);
            button3.Name = "button3";
            button3.Size = new Size(59, 24);
            button3.TabIndex = 5;
            button3.Text = "Clear";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Yet R", 9F, FontStyle.Bold, GraphicsUnit.Point);
            button4.Location = new Point(540, 273);
            button4.Name = "button4";
            button4.Size = new Size(59, 24);
            button4.TabIndex = 6;
            button4.Text = "Save";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(605, 273);
            button5.Name = "button5";
            button5.Size = new Size(59, 24);
            button5.TabIndex = 7;
            button5.Text = "Load";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(735, 273);
            button6.Name = "button6";
            button6.Size = new Size(69, 24);
            button6.TabIndex = 8;
            button6.Text = "Delete";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // second1
            // 
            second1.Location = new Point(12, 55);
            second1.Name = "second1";
            second1.Size = new Size(145, 29);
            second1.TabIndex = 9;
            second1.Text = "1 Second Test";
            second1.UseVisualStyleBackColor = true;
            second1.Click += button7_Click;
            // 
            // button7
            // 
            button7.Location = new Point(12, 90);
            button7.Name = "button7";
            button7.Size = new Size(145, 29);
            button7.TabIndex = 10;
            button7.Text = "5 Second Test";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click_1;
            // 
            // button8
            // 
            button8.Location = new Point(12, 125);
            button8.Name = "button8";
            button8.Size = new Size(145, 29);
            button8.TabIndex = 11;
            button8.Text = "10 Second Test";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(12, 160);
            button9.Name = "button9";
            button9.Size = new Size(145, 29);
            button9.TabIndex = 12;
            button9.Text = "60 Second Test";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // label1
            // 
            label1.Font = new Font("Yet R", 28F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(267, 55);
            label1.Name = "label1";
            label1.Size = new Size(124, 49);
            label1.TabIndex = 1;
            label1.Text = "5";
            label1.Click += label1_Click;
            // 
            // button10
            // 
            button10.Font = new Font("Yet R", 7F, FontStyle.Bold, GraphicsUnit.Point);
            button10.Location = new Point(12, 195);
            button10.Name = "button10";
            button10.Size = new Size(145, 29);
            button10.TabIndex = 13;
            button10.Text = "100 Second Test";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(12, 230);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(150, 25);
            numericUpDown1.TabIndex = 15;
            numericUpDown1.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(12, 320);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(150, 16);
            linkLabel1.TabIndex = 16;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "milk4lyfe.github.io";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(900, 360);
            Controls.Add(linkLabel1);
            Controls.Add(numericUpDown1);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(second1);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(listBox1);
            Controls.Add(button2);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Font = new Font("Yet R", 9F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(4, 2, 4, 2);
            Name = "Form1";
            Text = "CPS Test";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private System.Windows.Forms.Timer timer1;
        private Label label2;
        private Button button2;
        private ListBox listBox1;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button second1;
        private Button button7;
        private Button button8;
        private Button button9;
        private Label label1;
        private Button button10;
        private NumericUpDown numericUpDown1;
        private LinkLabel linkLabel1;
    }
}