using System;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using System.Security.Policy;
using System.Windows.Forms;
namespace Clickity
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
            this.Icon = new Icon("cursor.ico");
            mode = 5;

        }
        public float timeLeft = 0;
        public float clicks = 0;
        public bool started = false;
        private void button1_Click(object sender, EventArgs e)
        {

            if (timeLeft == 0)
            {
                started = true;
                button2.Enabled = true;
                clicks = 0;
                timer1.Start();
                timeLeft = mode;
                label1.Text = timeLeft.ToString();

            }
            clicks++;
            label2.Text = clicks.ToString() + " clicks";



        }
        DateTime now = DateTime.Now;
        DateTime dateTime = DateTime.Now;
        private void timer1_Tick_1(object sender, EventArgs e)
        {



            timeLeft--;
            label1.Text = timeLeft.ToString();



            if (timeLeft == 0)
            {
                button1.Enabled = false;
                started = false;
                button2.Enabled = true;
                button1.Text = "You got " + clicks / 5 + " cps";

                timer1.Stop();
                listBox1.Items.Add(clicks / mode + " CPS - " + mode + "s test - " + dateTime.ToString("MM/dd/yyyy HH:mm:ss"));
                label1.Text = timeLeft.ToString();
            }





        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }



        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            started = false;
            timer1.Stop();
            clicks = 0;
            button2.Enabled = false;
            timeLeft = 0;
            button1.Text = "Click to start";
            label1.Text = mode.ToString();
            button1.Enabled = true;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
        const string sPath = "score.txt";
        private void button4_Click(object sender, EventArgs e)
        {
            System.IO.StreamWriter SaveFile = new System.IO.StreamWriter(sPath);
            foreach (var item in listBox1.Items)
            {
                SaveFile.WriteLine(item.ToString());

            }
            SaveFile.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            System.IO.StreamReader SaveFile = new System.IO.StreamReader(sPath);
            string[] lines = File.ReadAllLines(sPath);

            foreach (string line in lines)
                listBox1.Items.Add(line);

            SaveFile.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (this.listBox1.SelectedIndex >= 0)
                this.listBox1.Items.RemoveAt(this.listBox1.SelectedIndex);

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        public float mode = 0;
        private void button7_Click(object sender, EventArgs e)
        {
            started = false;
            timer1.Stop();
            clicks = 0;
            button2.Enabled = false;
            timeLeft = 0;
            button1.Text = "Click to start";
            label1.Text = mode.ToString();
            button1.Enabled = true;
            mode = 1;
            numericUpDown1.Text = "1";
            label1.Text = "1";
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            started = false;
            timer1.Stop();
            clicks = 0;
            button2.Enabled = false;
            timeLeft = 0;
            button1.Text = "Click to start";
            label1.Text = mode.ToString();
            button1.Enabled = true;
            mode = 5;
            numericUpDown1.Text = "5";
            label1.Text = "5";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            started = false;
            timer1.Stop();
            clicks = 0;
            button2.Enabled = false;
            timeLeft = 0;
            button1.Text = "Click to start";
            label1.Text = mode.ToString();
            button1.Enabled = true;
            mode = 10;
            numericUpDown1.Text = "10";
            label1.Text = "10";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            started = false;
            timer1.Stop();
            clicks = 0;
            button2.Enabled = false;
            timeLeft = 0;
            button1.Text = "Click to start";
            label1.Text = mode.ToString();
            button1.Enabled = true;
            mode = 60;
            numericUpDown1.Text = "60";
            label1.Text = "60";
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            mode = float.Parse(numericUpDown1.Text);
            label1.Text = mode.ToString();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            started = false;
            timer1.Stop();
            clicks = 0;
            button2.Enabled = false;
            timeLeft = 0;
            button1.Text = "Click to start";
            label1.Text = mode.ToString();
            button1.Enabled = true;
            mode = 100;
            numericUpDown1.Text = "100";
            label1.Text = "100";
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start(new ProcessStartInfo { FileName = @"http://milk4lyfe.github.io", UseShellExecute = true });
        }

    }
}
